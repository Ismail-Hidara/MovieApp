package com.pfe.movieapp.service;

import com.pfe.movieapp.model.History;
import com.pfe.movieapp.model.User;
import com.pfe.movieapp.repository.HistoryRepository;
import com.pfe.movieapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class HistoryService {

    @Autowired
    private HistoryRepository historyRepository;

    @Autowired
    private UserRepository userRepository;

    public List<History> getUserHistory(Long userId) {
        return historyRepository.findByUserId(userId);
    }

    public History addToHistory(Long userId, History historyItem) {
        if (!historyRepository.existsByUserIdAndMovieId(userId, historyItem.getMovieId())) {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            historyItem.setUser(user);
            historyItem.setWatchedAt(LocalDateTime.now()); // fallback in case @CreationTimestamp isn't used
            return historyRepository.save(historyItem);
        } else {
            throw new RuntimeException("Already in history");
        }
    }
}
