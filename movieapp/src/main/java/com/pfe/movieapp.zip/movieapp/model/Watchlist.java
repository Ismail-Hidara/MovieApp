package com.pfe.movieapp.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(
        uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "movieId"})
)
public class Watchlist {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long movieId; // TMDB movie ID
    private String title;
    private String posterPath;

    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonIgnore

    private User user;
}
