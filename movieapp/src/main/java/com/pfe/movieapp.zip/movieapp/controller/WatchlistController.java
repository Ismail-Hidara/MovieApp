package com.pfe.movieapp.controller;

import com.pfe.movieapp.model.Watchlist;
import com.pfe.movieapp.service.WatchlistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/watchlist")
@CrossOrigin
public class WatchlistController {

    @Autowired
    private WatchlistService watchlistService;

    // ✅ Get user's watchlist
    @GetMapping("/{userId}")
    public List<Watchlist> getUserWatchlist(@PathVariable Long userId) {
        return watchlistService.getUserWatchlist(userId);
    }

    // ✅ Add to watchlist
    @PostMapping("/{userId}")
    public ResponseEntity<?> addToWatchlist(@PathVariable Long userId, @RequestBody Watchlist watchlistItem) {
        try {
            Watchlist savedItem = watchlistService.addToWatchlist(userId, watchlistItem);
            return ResponseEntity.ok(savedItem);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // ✅ Remove from watchlist
    @DeleteMapping("/{userId}/{movieId}")
    public ResponseEntity<?> removeFromWatchlist(@PathVariable Long userId, @PathVariable Long movieId) {
        watchlistService.removeFromWatchlist(userId, movieId);
        return ResponseEntity.ok().build();
    }
}
