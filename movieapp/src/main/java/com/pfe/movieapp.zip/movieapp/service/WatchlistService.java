package com.pfe.movieapp.service;

import com.pfe.movieapp.model.User;
import com.pfe.movieapp.model.Watchlist;
import com.pfe.movieapp.repository.UserRepository;
import com.pfe.movieapp.repository.WatchlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class WatchlistService {

    @Autowired
    private WatchlistRepository watchlistRepository;

    @Autowired
    private UserRepository userRepository;

    public List<Watchlist> getUserWatchlist(Long userId) {
        return watchlistRepository.findByUserId(userId);
    }

    public Watchlist addToWatchlist(Long userId, Watchlist watchlistItem) {
        if (!watchlistRepository.existsByUserIdAndMovieId(userId, watchlistItem.getMovieId())) {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            watchlistItem.setUser(user);
            return watchlistRepository.save(watchlistItem);
        } else {
            throw new RuntimeException("Movie already in watchlist");
        }
    }

    public void removeFromWatchlist(Long userId, Long movieId) {
        watchlistRepository.deleteByUserIdAndMovieId(userId, movieId);
    }
}
